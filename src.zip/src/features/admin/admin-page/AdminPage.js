"use client";
import React from "react";
import { Layout } from "./components/layout";
import "./styles/admin-page.css";
const AdminPage = () => {
  return (
    <Layout/>
  );
};

export default AdminPage;

import React from "react";
import "./styles/create-listing.css";
import CreateListingForm from "./components/CreateListingForm";
const CreateListingPage = () => {
  return (
    <div>
      <CreateListingForm />
    </div>
  );
};

export default CreateListingPage;

import React from 'react'
import './styles/dashboard-page.css'
const DashboardPage = () => {
  return (
    <div>
        
    </div>
  )
}

export default DashboardPage
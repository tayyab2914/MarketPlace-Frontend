export const TESTIMONIALS_CONTENT = [
    {
      id: 1,
      rating: 5,
      text: "Incredibly impressed on-demand cleaning service. Prompt, thorough and left home sparkling. A game-changer for busy schedules! Uber has transformed my daily commute. Reliable easy booking, and the app's convenience",
      author: "Devon Lane",
      handle: "@iamsedaoi&wv",
      avatar: "/placeholder.svg?height=48&width=48&text=DL",
    },
    {
      id: 2,
      rating: 5,
      text: "Incredibly impressed on-demand cleaning service. Prompt, thorough and left home sparkling. A game-changer for busy schedules! Uber has transformed my daily commute. Reliable easy booking, and the app's convenience",
      author: "Devon Lane",
      handle: "@iamsedaoi&wv",
      avatar: "/placeholder.svg?height=48&width=48&text=DL",
    },
    {
      id: 3,
      rating: 5,
      text: "Incredibly impressed on-demand cleaning service. Prompt, thorough and left home sparkling. A game-changer for busy schedules! Uber has transformed my daily commute. Reliable easy booking, and the app's convenience",
      author: "Devon Lane",
      handle: "@iamsedaoi&wv",
      avatar: "/placeholder.svg?height=48&width=48&text=DL",
    },
    {
      id: 4,
      rating: 5,
      text: "Incredibly impressed on-demand cleaning service. Prompt, thorough and left home sparkling. A game-changer for busy schedules! Uber has transformed my daily commute. Reliable easy booking, and the app's convenience",
      author: "Devon Lane",
      handle: "@iamsedaoi&wv",
      avatar: "/placeholder.svg?height=48&width=48&text=DL",
    },
  ];
  